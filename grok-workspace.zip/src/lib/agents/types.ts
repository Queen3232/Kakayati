export type AgentId = "brief" | "plan" | "build" | "review";
export type AgentStatus = "idle" | "thinking" | "waiting" | "done" | "error";
export type Phase = "brief" | "plan" | "build" | "review" | "done";

export interface InterviewTurn {
  question: string;
  answer: string;
}

export interface ProjectFile {
  path: string;
  content: string;
}

export interface LogEntry {
  id: string;
  at: string;
  agent: AgentId;
  kind: "think" | "say" | "file" | "decision" | "issue";
  text: string;
}

export interface Session {
  id: string;
  task: string;
  createdAt: string;
  updatedAt: string;
  phase: Phase;
  agentStatus: Record<AgentId, AgentStatus>;
  interview: InterviewTurn[];
  pendingQuestion: string | null;
  spec: string;
  plan: string;
  files: ProjectFile[];
  review: {
    cycles: number;
    comments: string;
    approved: boolean;
    issues: string[];
    pendingFix: boolean;
  };
  blackboard: {
    decisions: string[];
    issues: string[];
    notes: string[];
  };
  log: LogEntry[];
  stats: { calls: number; durationMs: number };
  error: string | null;
  busy: boolean;
}

export const AGENT_META: Record<
  AgentId,
  { name: string; title: string; duty: string; index: string }
> = {
  brief: {
    name: "Brief",
    title: "Analyst",
    duty: "Asks the questions that turn a wish into a spec.",
    index: "01",
  },
  plan: {
    name: "Plan",
    title: "Architect",
    duty: "Sequences the work so the build has a spine.",
    index: "02",
  },
  build: {
    name: "Build",
    title: "Engineer",
    duty: "Writes the files. No slides, no vapor.",
    index: "03",
  },
  review: {
    name: "Review",
    title: "Critic",
    duty: "Finds the holes before they ship.",
    index: "04",
  },
};

export const PHASES: Phase[] = ["brief", "plan", "build", "review", "done"];

export const MAX_INTERVIEW = 4;
export const MAX_REVIEW_CYCLES = 2;

export function emptyAgentStatus(): Record<AgentId, AgentStatus> {
  return {
    brief: "idle",
    plan: "idle",
    build: "idle",
    review: "idle",
  };
}

export function createSession(task: string): Session {
  const now = new Date().toISOString();
  return {
    id:
      typeof crypto !== "undefined" && crypto.randomUUID
        ? crypto.randomUUID()
        : `s_${Date.now().toString(36)}`,
    task: task.trim(),
    createdAt: now,
    updatedAt: now,
    phase: "brief",
    agentStatus: { ...emptyAgentStatus(), brief: "thinking" },
    interview: [],
    pendingQuestion: null,
    spec: "",
    plan: "",
    files: [],
    review: { cycles: 0, comments: "", approved: false, issues: [], pendingFix: false },
    blackboard: { decisions: [], issues: [], notes: [] },
    log: [],
    stats: { calls: 0, durationMs: 0 },
    error: null,
    busy: true,
  };
}
