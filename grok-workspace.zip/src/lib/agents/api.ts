import { createServerFn } from "@tanstack/react-start";
import type { AgentId, InterviewTurn, ProjectFile } from "./types";
import { MAX_INTERVIEW } from "./types";

export type AgentStep = "question" | "spec" | "plan" | "build" | "review" | "fix";

export interface AgentRequest {
  step: AgentStep;
  task: string;
  interview?: InterviewTurn[];
  answer?: string;
  spec?: string;
  plan?: string;
  files?: ProjectFile[];
  reviewComments?: string;
}

export type AgentResponse =
  | { ok: true; text: string }
  | { ok: false; error: string };

export const getAiStatus = createServerFn({ method: "POST" }).handler(async () => {
  return { available: Boolean(process.env.XAI_API_KEY) };
});

const STEP_LIMITS: Record<AgentStep, { maxTokens: number; json: boolean; temperature: number }> = {
  question: { maxTokens: 500, json: true, temperature: 0.6 },
  spec: { maxTokens: 1400, json: true, temperature: 0.4 },
  plan: { maxTokens: 1600, json: false, temperature: 0.4 },
  build: { maxTokens: 3600, json: true, temperature: 0.3 },
  review: { maxTokens: 1200, json: true, temperature: 0.3 },
  fix: { maxTokens: 2800, json: true, temperature: 0.3 },
};

function clip(text: string, n: number): string {
  if (text.length <= n) return text;
  return `${text.slice(0, n)}\n…[truncated]`;
}

function compactFiles(files: ProjectFile[] | undefined): string {
  if (!files?.length) return "(no files yet)";
  return files
    .slice(0, 8)
    .map((f) => `### ${f.path}\n\`\`\`\n${clip(f.content, 2800)}\n\`\`\``)
    .join("\n\n");
}

function buildMessages(data: AgentRequest): { role: AgentId; messages: { role: "system" | "user"; content: string }[] } {
  const task = clip(data.task.trim(), 2000);
  const interview = (data.interview ?? []).slice(0, MAX_INTERVIEW);
  const qa = interview
    .map((t, i) => `Q${i + 1}: ${t.question}\nA${i + 1}: ${clip(t.answer, 1500)}`)
    .join("\n\n");
  const pendingAnswer = clip((data.answer ?? "").trim(), 2000);

  switch (data.step) {
    case "question": {
      const asked = interview.length;
      return {
        role: "brief",
        messages: [
          {
            role: "system",
            content: `You are Brief, the analyst in Quorum, a four-agent software studio.
Interview the user about their software brief. Ask ONE sharp question at a time.
Never greet. Never stack questions. Prefer constraints, users, platform, and must-haves.
You have asked ${asked} of ${MAX_INTERVIEW} questions.
If you have enough to write a spec, or this would be question ${MAX_INTERVIEW}, finish instead.
Return JSON only: {"status":"ask","question":"..."} or {"status":"spec","spec":"# Spec\\n..."}.
The spec is Markdown covering goal, users, scope, non-goals, UX, data, and acceptance checks.`,
          },
          {
            role: "user",
            content: `Brief:\n${task}\n\nInterview so far:\n${qa || "(none)"}\n\n${
              pendingAnswer ? `Latest answer:\n${pendingAnswer}` : "Ask the first question, or write the spec if the brief is already complete."
            }`,
          },
        ],
      };
    }
    case "spec":
      return {
        role: "brief",
        messages: [
          {
            role: "system",
            content: `You are Brief, the analyst in Quorum.
Write a tight product spec in Markdown from the brief and interview.
Return JSON only: {"status":"spec","spec":"# Spec\\n..."}.
Include goal, users, scope, non-goals, UX, data, and acceptance checks. No code.`,
          },
          {
            role: "user",
            content: `Brief:\n${task}\n\nInterview:\n${qa || "(none)"}`,
          },
        ],
      };
    case "plan":
      return {
        role: "plan",
        messages: [
          {
            role: "system",
            content: `You are Plan, the architect in Quorum.
Write a concrete implementation plan in Markdown: stack, file map, data shape, step order, risks.
No code dumps. Keep it under ~500 words. Plain headings and lists.`,
          },
          {
            role: "user",
            content: `Brief:\n${task}\n\nSpec:\n${clip(data.spec ?? "", 4000)}`,
          },
        ],
      };
    case "build":
      return {
        role: "build",
        messages: [
          {
            role: "system",
            content: `You are Build, the engineer in Quorum.
Ship a small, complete, runnable project (3–8 files). Production-quality, no placeholders, no lorem.
Prefer a single HTML file plus CSS/JS when that can stand alone; otherwise a tiny web app.
Return JSON only:
{"summary":"one paragraph","files":[{"path":"relative/path","content":"full file contents"}]}.
Paths must be relative. Do not wrap JSON in commentary.`,
          },
          {
            role: "user",
            content: `Brief:\n${task}\n\nSpec:\n${clip(data.spec ?? "", 3500)}\n\nPlan:\n${clip(data.plan ?? "", 3000)}`,
          },
        ],
      };
    case "review":
      return {
        role: "review",
        messages: [
          {
            role: "system",
            content: `You are Review, the critic in Quorum.
Judge the files against the spec and plan. Be specific. Approve only if it would actually run and match the brief.
Return JSON only:
{"verdict":"approved"|"changes","summary":"...","issues":["..."]}.
Max 5 issues. If approved, issues may be empty.`,
          },
          {
            role: "user",
            content: `Brief:\n${task}\n\nSpec:\n${clip(data.spec ?? "", 2500)}\n\nPlan:\n${clip(data.plan ?? "", 2000)}\n\nFiles:\n${compactFiles(data.files)}`,
          },
        ],
      };
    case "fix":
      return {
        role: "build",
        messages: [
          {
            role: "system",
            content: `You are Build, the engineer in Quorum.
Apply the review. Return the FULL updated set of files (not a diff), still 3–8 files.
Return JSON only:
{"summary":"what changed","files":[{"path":"relative/path","content":"full file contents"}]}.`,
          },
          {
            role: "user",
            content: `Brief:\n${task}\n\nSpec:\n${clip(data.spec ?? "", 2500)}\n\nReview:\n${clip(data.reviewComments ?? "", 2500)}\n\nCurrent files:\n${compactFiles(data.files)}`,
          },
        ],
      };
  }
}

async function chatOnce(messages: { role: "system" | "user"; content: string }[], step: AgentStep): Promise<AgentResponse> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) {
    return { ok: false, error: "AI is not available in this environment." };
  }
  const limits = STEP_LIMITS[step];
  const body: Record<string, unknown> = {
    model: "grok-4.5",
    messages,
    temperature: limits.temperature,
    max_tokens: limits.maxTokens,
  };
  if (limits.json) {
    body.response_format = { type: "json_object" };
  }

  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(90_000),
  });

  if (!res.ok) {
    return { ok: false, error: `The model could not complete this turn (${res.status}).` };
  }
  const json = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const text = json.choices?.[0]?.message?.content?.trim() ?? "";
  if (!text) return { ok: false, error: "Empty reply from the model." };
  return { ok: true, text };
}

export const runAgentStep = createServerFn({ method: "POST" })
  .validator((input: AgentRequest) => {
    if (!input || typeof input !== "object") throw new Error("Invalid request");
    if (!input.task || typeof input.task !== "string") throw new Error("A brief is required");
    const steps: AgentStep[] = ["question", "spec", "plan", "build", "review", "fix"];
    if (!steps.includes(input.step)) throw new Error("Unknown step");
    return {
      ...input,
      task: input.task.slice(0, 2000),
      answer: input.answer?.slice(0, 2000),
      spec: input.spec?.slice(0, 8000),
      plan: input.plan?.slice(0, 8000),
      reviewComments: input.reviewComments?.slice(0, 4000),
      files: (input.files ?? []).slice(0, 12).map((f) => ({
        path: String(f.path).slice(0, 180),
        content: String(f.content).slice(0, 12000),
      })),
      interview: (input.interview ?? []).slice(0, MAX_INTERVIEW).map((t) => ({
        question: String(t.question).slice(0, 800),
        answer: String(t.answer).slice(0, 2000),
      })),
    } satisfies AgentRequest;
  })
  .handler(async ({ data }): Promise<AgentResponse> => {
    const packed = buildMessages(data);
    const first = await chatOnce(packed.messages, data.step);
    if (first.ok) return first;
    if (first.error.includes("not available")) return first;
    const retry = await chatOnce(packed.messages, data.step);
    return retry;
  });
