import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as LayoutGrid, d as ArrowLeft, i as ListTree, l as Check, o as Download, r as RotateCcw, s as Copy, t as Users, u as ArrowRight } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as truncate, d as useSessionStore, f as AGENT_META, n as Route, r as cn, u as useSession } from "./router-BNZVNUDC.mjs";
import { a as applyFixes, d as runReview, i as answerQuestion, l as retryLast, n as Textarea, r as Wordmark, s as composePlan, t as Button, u as runBuild } from "./logo-Cx0IxkYu.mjs";
import { a as Viewport, i as ScrollAreaThumb, n as Root, r as ScrollAreaScrollbar, t as Corner } from "../_libs/radix-ui__react-scroll-area.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio._id-C58tlJ1Q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function downloadText(filename, content, mime = "text/plain;charset=utf-8") {
	const blob = new Blob([content], { type: mime });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function filesAsBundle(files) {
	return files.map((f) => `===== ${f.path} =====\n${f.content.replace(/\n$/, "")}\n`).join("\n");
}
function exportSession(session) {
	downloadText(`${session.task.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "project"}.txt`, filesAsBundle(session.files));
}
function copyText(text) {
	return navigator.clipboard.writeText(text);
}
var ITEMS = [
	"brief",
	"plan",
	"build",
	"review"
];
function PhaseBar({ phase }) {
	const current = phase === "done" ? 4 : ITEMS.indexOf(phase);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "flex items-center gap-1 overflow-x-auto",
		children: ITEMS.map((id, i) => {
			const done = i < current || phase === "done";
			const active = i === current && phase !== "done";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex min-w-0 items-center gap-1",
				children: [i > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mx-1 hidden h-px w-6 bg-border sm:block" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs", active && "bg-subtle text-fg", done && "text-muted", !done && !active && "text-faint"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("flex size-4 items-center justify-center rounded-full text-[10px]", done && "bg-subtle text-ok", active && "bg-accent text-accent-fg", !done && !active && "bg-subtle text-faint"),
						children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-2.5" }) : i + 1
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: AGENT_META[id].name
					})]
				})]
			}, id);
		})
	});
}
var ORDER = [
	"brief",
	"plan",
	"build",
	"review"
];
function statusLabel(status) {
	switch (status) {
		case "thinking": return "Working";
		case "waiting": return "Waiting on you";
		case "done": return "Complete";
		case "error": return "Needs attention";
		default: return "Idle";
	}
}
function AgentRoster({ session }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-1",
		children: ORDER.map((id) => {
			const meta = AGENT_META[id];
			const status = session.agentStatus[id];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: cn("rounded-md px-3 py-3 transition-colors duration-150", status === "thinking" || status === "waiting" ? "bg-subtle" : "bg-transparent"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-base font-medium text-fg",
							children: meta.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-[10px] tabular-nums text-faint",
							children: meta.index
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: meta.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-2 text-xs", status === "thinking" && "shimmer-text", status === "waiting" && "text-fg", status === "done" && "text-ok", status === "error" && "text-danger", status === "idle" && "text-faint"),
						children: statusLabel(status)
					})
				]
			}, id);
		})
	});
}
function BlackboardPanel({ session }) {
	const { decisions, issues, notes } = session.blackboard;
	const empty = decisions.length + issues.length + notes.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-faint",
				children: "Blackboard"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: "Shared memory for the crew."
			})] }),
			empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-faint",
				children: "Nothing posted yet. It fills as specialists work."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardList, {
				title: "Decisions",
				items: decisions
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardList, {
				title: "Issues",
				items: issues,
				tone: "danger"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardList, {
				title: "Notes",
				items: notes
			})
		]
	});
}
function BoardList({ title, items, tone }) {
	if (items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-medium text-muted",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 space-y-2",
		children: items.slice().reverse().map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: tone === "danger" ? "text-sm text-danger" : "text-sm text-fg",
			children: item
		}, `${item}-${i}`))
	})] });
}
var ScrollArea = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root, {
	ref,
	className: cn("relative overflow-hidden", className),
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
			className: "h-full w-full rounded-[inherit]",
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollBar, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Corner, {})
	]
}));
ScrollArea.displayName = Root.displayName;
var ScrollBar = import_react.forwardRef(({ className, orientation = "vertical", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbar, {
	ref,
	orientation,
	className: cn("flex touch-none select-none p-px transition-colors", orientation === "vertical" && "h-full w-2 border-l border-l-transparent", orientation === "horizontal" && "h-2 flex-col border-t border-t-transparent", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaThumb, { className: "relative flex-1 rounded-full bg-border-strong" })
}));
ScrollBar.displayName = ScrollAreaScrollbar.displayName;
function FilesPanel({ files, onExport }) {
	const [active, setActive] = (0, import_react.useState)(files[0]?.path ?? "");
	const current = files.find((f) => f.path === active) ?? files[0];
	const [copied, setCopied] = (0, import_react.useState)(false);
	if (files.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-48 flex-col items-center justify-center px-4 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "No files yet."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-faint",
			children: "Build will drop a project here."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2 px-1 pb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-faint",
				children: ["Files", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-2 font-mono tabular-nums text-muted",
					children: files.length
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: onExport,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Export"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg bg-elevated shadow-[var(--shadow-border)] lg:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex max-h-32 shrink-0 gap-1 overflow-x-auto border-b border-border p-2 lg:max-h-none lg:w-48 lg:flex-col lg:overflow-y-auto lg:border-b-0 lg:border-r",
				children: files.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "min-w-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActive(f.path),
						className: cn("w-full truncate rounded-sm px-2 py-2 text-left font-mono text-[11px] transition-colors duration-150", current?.path === f.path ? "bg-subtle text-fg" : "text-muted hover:text-fg"),
						children: f.path
					})
				}, f.path))
			}), current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 border-b border-border px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-mono text-xs text-muted",
						children: current.path
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "size-9 min-h-9 min-w-9",
							onClick: () => {
								copyText(current.content).then(() => {
									setCopied(true);
									window.setTimeout(() => setCopied(false), 1200);
								});
							},
							"aria-label": "Copy file",
							children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "size-9 min-h-9 min-w-9",
							onClick: () => downloadText(current.path.split("/").pop() ?? "file.txt", current.content),
							"aria-label": "Download file",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
					className: "min-h-0 flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "p-3 font-mono text-[11px] leading-relaxed text-fg",
						children: current.content
					})
				})]
			}) : null]
		})]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-subtle text-muted",
		solid: "bg-accent text-accent-fg",
		ok: "bg-subtle text-ok",
		warn: "bg-subtle text-warn",
		danger: "bg-subtle text-danger"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function renderInline(text, keyPrefix) {
	return text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).map((part, i) => {
		const key = `${keyPrefix}-${i}`;
		if (part.startsWith("**") && part.endsWith("**")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: "font-medium text-fg",
			children: part.slice(2, -2)
		}, key);
		if (part.startsWith("`") && part.endsWith("`")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "rounded-xs bg-subtle px-1 font-mono text-[0.85em] text-fg",
			children: part.slice(1, -1)
		}, key);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: part }, key);
	});
}
function MarkdownView({ text, className }) {
	const blocks = text.replace(/\r\n/g, "\n").split(/\n{2,}/);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("space-y-3 text-sm leading-relaxed text-muted", className),
		children: blocks.map((block, i) => {
			const lines = block.split("\n");
			const first = lines[0] ?? "";
			if (first.startsWith("```")) {
				const body = lines.slice(1).join("\n").replace(/```$/, "");
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "overflow-x-auto rounded-md bg-subtle p-3 font-mono text-xs text-fg shadow-[var(--shadow-border)]",
					children: body
				}, i);
			}
			if (first.startsWith("# ")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-xl font-medium text-fg",
				children: first.slice(2)
			}, i);
			if (first.startsWith("## ")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: "font-display text-lg font-medium text-fg",
				children: first.slice(3)
			}, i);
			if (first.startsWith("### ")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
				className: "text-sm font-medium text-fg",
				children: first.slice(4)
			}, i);
			if (lines.every((l) => l.trim().startsWith("- ") || l.trim().startsWith("* "))) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1 pl-4",
				children: lines.map((l, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "list-disc",
					children: renderInline(l.replace(/^\s*[-*]\s+/, ""), `${i}-${j}`)
				}, j))
			}, i);
			if (lines.every((l) => /^\s*\d+\.\s+/.test(l))) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-1 pl-4",
				children: lines.map((l, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "list-decimal",
					children: renderInline(l.replace(/^\s*\d+\.\s+/, ""), `${i}-${j}`)
				}, j))
			}, i);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: lines.map((line, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [j > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}) : null, renderInline(line, `${i}-${j}`)] }, j)) }, i);
		})
	});
}
function WorkPanel({ session }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			session.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-subtle px-4 py-3 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: session.error
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					className: "mt-3",
					disabled: session.busy,
					onClick: () => void retryLast(session.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Try again"]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BriefSection, { session }),
			session.spec ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanSection, { session }) : null,
			session.plan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildSection, { session }) : null,
			session.files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewSection, { session }) : null
		]
	});
}
function BriefSection({ session }) {
	const [answer, setAnswer] = (0, import_react.useState)("");
	const waiting = Boolean(session.pendingQuestion) && !session.busy;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
			kicker: "01",
			title: "Brief",
			hint: "Analyst"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: session.task
		}),
		session.interview.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-5 space-y-4",
			children: session.interview.map((turn, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-fg",
					children: turn.question
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-md bg-subtle px-3 py-2 text-sm text-muted",
					children: turn.answer
				})]
			}, i))
		}) : null,
		session.pendingQuestion ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 rounded-lg bg-elevated p-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-medium uppercase tracking-[0.14em] text-faint",
					children: [
						"Question ",
						session.interview.length + 1,
						" of ",
						4
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-base text-fg",
					children: session.pendingQuestion
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 space-y-3",
					onSubmit: (e) => {
						e.preventDefault();
						const next = answer.trim();
						if (!next) return;
						setAnswer("");
						answerQuestion(session.id, next);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: answer,
						onChange: (e) => setAnswer(e.target.value),
						onKeyDown: (e) => {
							if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
								e.preventDefault();
								const next = answer.trim();
								if (!next || !waiting) return;
								setAnswer("");
								answerQuestion(session.id, next);
							}
						},
						placeholder: "Answer here…",
						disabled: !waiting,
						className: "min-h-24 bg-bg"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: !waiting || !answer.trim(),
						className: "w-full sm:w-auto",
						children: ["Send answer", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})]
				})
			]
		}) : null,
		session.busy && session.agentStatus.brief === "thinking" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "shimmer-text mt-4 text-sm",
			children: "Listening…"
		}) : null,
		session.spec ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-faint",
				children: "Spec"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 rounded-lg bg-elevated p-4 shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: session.spec })
			})]
		}) : null
	] });
}
function PlanSection({ session }) {
	const ready = !session.plan && !session.busy && Boolean(session.spec);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
		kicker: "02",
		title: "Plan",
		hint: "Architect"
	}), session.plan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 rounded-lg bg-elevated p-4 shadow-[var(--shadow-border)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: session.plan })
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4",
		children: session.busy && session.agentStatus.plan === "thinking" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "shimmer-text text-sm",
			children: "Drafting the plan…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			disabled: !ready,
			onClick: () => void composePlan(session.id),
			children: ["Compose the plan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
		})
	})] });
}
function BuildSection({ session }) {
	const ready = session.files.length === 0 && !session.busy && Boolean(session.plan);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
		kicker: "03",
		title: "Build",
		hint: "Engineer"
	}), session.files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-3 text-sm text-muted",
		children: [session.files.length, " files on the board. Open the Files tab to read them."]
	}) : session.busy && session.agentStatus.build === "thinking" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "shimmer-text mt-3 text-sm",
		children: "Writing files…"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		className: "mt-4",
		disabled: !ready,
		onClick: () => void runBuild(session.id),
		children: ["Build the project", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
	})] });
}
function ReviewSection({ session }) {
	const { review } = session;
	const canReview = !session.busy && session.files.length > 0 && !review.approved && !review.pendingFix;
	const canFix = !session.busy && review.pendingFix && review.cycles <= 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
			kicker: "04",
			title: "Review",
			hint: "Critic"
		}),
		review.comments ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 rounded-lg bg-elevated p-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: review.approved ? "ok" : "warn",
					children: review.approved ? "Approved" : "Changes requested"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: review.comments
				}),
				review.issues.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-1",
					children: review.issues.map((issue) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-danger",
						children: issue
					}, issue))
				}) : null
			]
		}) : null,
		session.busy && session.agentStatus.review === "thinking" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "shimmer-text mt-3 text-sm",
			children: "Reading the files…"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-wrap gap-2",
			children: [
				canReview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void runReview(session.id),
					children: ["Run review", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
				}) : null,
				canFix ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void applyFixes(session.id),
					children: ["Apply fixes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
				}) : null,
				review.approved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-ok",
					children: "The critic signed off. Export the files when you are ready."
				}) : null
			]
		})
	] });
}
function Header({ kicker, title, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl font-medium text-fg",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-mono text-[11px] tabular-nums text-faint",
			children: [
				kicker,
				" · ",
				hint
			]
		})]
	});
}
function StudioPage({ id }) {
	const session = useSession(id);
	const hydrated = useSessionStore((s) => s.hydrated);
	const [tab, setTab] = (0, import_react.useState)("work");
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-sm text-muted",
		children: "Restoring session…"
	});
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl",
				children: "Session not found"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-sm text-muted",
				children: "It may have been cleared from this device. Open a new one from the studio home."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-2 text-sm text-fg underline decoration-border underline-offset-4",
				children: "Back to Quorum"
			})
		]
	});
	const duration = Math.round(session.stats.durationMs / 1e3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3 border-b border-border px-4 py-3 sm:px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex size-11 items-center justify-center rounded-md text-muted hover:bg-subtle hover:text-fg lg:hidden",
						"aria-label": "Back",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hidden h-5 w-px bg-border lg:block" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm text-fg",
							children: truncate(session.task, 80)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs tabular-nums text-faint",
							children: [
								session.stats.calls,
								" calls",
								duration > 0 ? ` · ${duration}s` : ""
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-border px-4 py-2 sm:px-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhaseBar, { phase: session.phase })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto hidden min-h-0 w-full max-w-[1400px] flex-1 grid-cols-[220px_minmax(0,1fr)_320px] gap-0 overflow-hidden lg:grid",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "min-h-0 border-r border-border p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentRoster, { session })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
						className: "min-h-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-6 py-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkPanel, { session })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "flex min-h-0 flex-col border-l border-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
							className: "max-h-[40%] border-b border-border p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlackboardPanel, { session })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-h-0 flex-1 flex-col p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilesPanel, {
								files: session.files,
								onExport: () => exportSession(session)
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
					className: "min-h-0 flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 py-5 pb-24",
						children: [
							tab === "work" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkPanel, { session }) : null,
							tab === "crew" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentRoster, { session }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlackboardPanel, { session })]
							}) : null,
							tab === "files" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilesPanel, {
								files: session.files,
								onExport: () => exportSession(session)
							}) : null
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mx-auto grid max-w-lg grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTabBtn, {
								active: tab === "work",
								onClick: () => setTab("work"),
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-4" }),
								label: "Work"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTabBtn, {
								active: tab === "crew",
								onClick: () => setTab("crew"),
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }),
								label: "Crew"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTabBtn, {
								active: tab === "files",
								onClick: () => setTab("files"),
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListTree, { className: "size-4" }),
								label: "Files"
							})
						]
					})
				})]
			})
		]
	});
}
function MobileTabBtn({ active, onClick, icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex h-14 w-full flex-col items-center justify-center gap-1 text-[11px]", active ? "text-fg" : "text-faint"),
		children: [icon, label]
	}) });
}
function Studio() {
	const { id } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioPage, { id });
}
//#endregion
export { Studio as component };
