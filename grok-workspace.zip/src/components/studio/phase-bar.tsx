import { Check } from "lucide-react";
import { AGENT_META, type AgentId, type Phase } from "@/lib/agents/types";
import { cn } from "@/lib/utils";

const ITEMS: AgentId[] = ["brief", "plan", "build", "review"];

export function PhaseBar({ phase }: { phase: Phase }) {
  const current = phase === "done" ? 4 : ITEMS.indexOf(phase);
  return (
    <ol className="flex items-center gap-1 overflow-x-auto">
      {ITEMS.map((id, i) => {
        const done = i < current || phase === "done";
        const active = i === current && phase !== "done";
        return (
          <li key={id} className="flex min-w-0 items-center gap-1">
            {i > 0 ? <span className="mx-1 hidden h-px w-6 bg-border sm:block" /> : null}
            <span
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs",
                active && "bg-subtle text-fg",
                done && "text-muted",
                !done && !active && "text-faint",
              )}
            >
              <span
                className={cn(
                  "flex size-4 items-center justify-center rounded-full text-[10px]",
                  done && "bg-subtle text-ok",
                  active && "bg-accent text-accent-fg",
                  !done && !active && "bg-subtle text-faint",
                )}
              >
                {done ? <Check className="size-2.5" /> : i + 1}
              </span>
              <span className="font-medium">{AGENT_META[id].name}</span>
            </span>
          </li>
        );
      })}
    </ol>
  );
}
