import type { ProjectFile, Session } from "./types";

export function downloadText(filename: string, content: string, mime = "text/plain;charset=utf-8") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function filesAsBundle(files: ProjectFile[]): string {
  return files
    .map((f) => `===== ${f.path} =====\n${f.content.replace(/\n$/, "")}\n`)
    .join("\n");
}

export function exportSession(session: Session) {
  const slug = session.task
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40) || "project";
  downloadText(`${slug}.txt`, filesAsBundle(session.files));
}

export function copyText(text: string): Promise<void> {
  return navigator.clipboard.writeText(text);
}
