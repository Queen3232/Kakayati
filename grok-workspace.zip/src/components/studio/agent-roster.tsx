import { AGENT_META, type AgentId, type AgentStatus, type Session } from "@/lib/agents/types";
import { cn } from "@/lib/utils";

const ORDER: AgentId[] = ["brief", "plan", "build", "review"];

function statusLabel(status: AgentStatus): string {
  switch (status) {
    case "thinking":
      return "Working";
    case "waiting":
      return "Waiting on you";
    case "done":
      return "Complete";
    case "error":
      return "Needs attention";
    default:
      return "Idle";
  }
}

export function AgentRoster({ session }: { session: Session }) {
  return (
    <ul className="space-y-1">
      {ORDER.map((id) => {
        const meta = AGENT_META[id];
        const status = session.agentStatus[id];
        const active = status === "thinking" || status === "waiting";
        return (
          <li
            key={id}
            className={cn(
              "rounded-md px-3 py-3 transition-colors duration-150",
              active ? "bg-subtle" : "bg-transparent",
            )}
          >
            <div className="flex items-baseline justify-between gap-2">
              <p className="font-display text-base font-medium text-fg">{meta.name}</p>
              <p className="font-mono text-[10px] tabular-nums text-faint">{meta.index}</p>
            </div>
            <p className="text-xs text-muted">{meta.title}</p>
            <p
              className={cn(
                "mt-2 text-xs",
                status === "thinking" && "shimmer-text",
                status === "waiting" && "text-fg",
                status === "done" && "text-ok",
                status === "error" && "text-danger",
                status === "idle" && "text-faint",
              )}
            >
              {statusLabel(status)}
            </p>
          </li>
        );
      })}
    </ul>
  );
}
