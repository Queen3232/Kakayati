import type { Session } from "@/lib/agents/types";

export function BlackboardPanel({ session }: { session: Session }) {
  const { decisions, issues, notes } = session.blackboard;
  const empty = decisions.length + issues.length + notes.length === 0;

  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-faint">Blackboard</p>
        <p className="mt-1 text-xs text-muted">Shared memory for the crew.</p>
      </div>
      {empty ? (
        <p className="text-sm text-faint">Nothing posted yet. It fills as specialists work.</p>
      ) : null}
      <BoardList title="Decisions" items={decisions} />
      <BoardList title="Issues" items={issues} tone="danger" />
      <BoardList title="Notes" items={notes} />
    </div>
  );
}

function BoardList({
  title,
  items,
  tone,
}: {
  title: string;
  items: string[];
  tone?: "danger";
}) {
  if (items.length === 0) return null;
  return (
    <div>
      <p className="text-xs font-medium text-muted">{title}</p>
      <ul className="mt-2 space-y-2">
        {items.slice().reverse().map((item, i) => (
          <li
            key={`${item}-${i}`}
            className={tone === "danger" ? "text-sm text-danger" : "text-sm text-fg"}
          >
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}
