import { useState } from "react";
import { Check, Copy, Download } from "lucide-react";
import type { ProjectFile } from "@/lib/agents/types";
import { copyText, downloadText } from "@/lib/agents/export";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

export function FilesPanel({
  files,
  onExport,
}: {
  files: ProjectFile[];
  onExport: () => void;
}) {
  const [active, setActive] = useState(files[0]?.path ?? "");
  const current = files.find((f) => f.path === active) ?? files[0];
  const [copied, setCopied] = useState(false);

  if (files.length === 0) {
    return (
      <div className="flex h-full min-h-48 flex-col items-center justify-center px-4 text-center">
        <p className="text-sm text-muted">No files yet.</p>
        <p className="mt-1 text-xs text-faint">Build will drop a project here.</p>
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-center justify-between gap-2 px-1 pb-2">
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-faint">
          Files
          <span className="ml-2 font-mono tabular-nums text-muted">{files.length}</span>
        </p>
        <Button variant="ghost" size="sm" onClick={onExport}>
          <Download />
          Export
        </Button>
      </div>
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg bg-elevated shadow-[var(--shadow-border)] lg:flex-row">
        <ul className="flex max-h-32 shrink-0 gap-1 overflow-x-auto border-b border-border p-2 lg:max-h-none lg:w-48 lg:flex-col lg:overflow-y-auto lg:border-b-0 lg:border-r">
          {files.map((f) => (
            <li key={f.path} className="min-w-0">
              <button
                type="button"
                onClick={() => setActive(f.path)}
                className={cn(
                  "w-full truncate rounded-sm px-2 py-2 text-left font-mono text-[11px] transition-colors duration-150",
                  (current?.path === f.path ? "bg-subtle text-fg" : "text-muted hover:text-fg"),
                )}
              >
                {f.path}
              </button>
            </li>
          ))}
        </ul>
        {current ? (
          <div className="flex min-h-0 min-w-0 flex-1 flex-col">
            <div className="flex items-center justify-between gap-2 border-b border-border px-3 py-2">
              <p className="truncate font-mono text-xs text-muted">{current.path}</p>
              <div className="flex">
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-9 min-h-9 min-w-9"
                  onClick={() => {
                    void copyText(current.content).then(() => {
                      setCopied(true);
                      window.setTimeout(() => setCopied(false), 1200);
                    });
                  }}
                  aria-label="Copy file"
                >
                  {copied ? <Check /> : <Copy />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-9 min-h-9 min-w-9"
                  onClick={() => downloadText(current.path.split("/").pop() ?? "file.txt", current.content)}
                  aria-label="Download file"
                >
                  <Download />
                </Button>
              </div>
            </div>
            <ScrollArea className="min-h-0 flex-1">
              <pre className="p-3 font-mono text-[11px] leading-relaxed text-fg">
                {current.content}
              </pre>
            </ScrollArea>
          </div>
        ) : null}
      </div>
    </div>
  );
}
