import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

function renderInline(text: string, keyPrefix: string): ReactNode[] {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((part, i) => {
    const key = `${keyPrefix}-${i}`;
    if (part.startsWith("**") && part.endsWith("**")) {
      return (
        <strong key={key} className="font-medium text-fg">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith("`") && part.endsWith("`")) {
      return (
        <code key={key} className="rounded-xs bg-subtle px-1 font-mono text-[0.85em] text-fg">
          {part.slice(1, -1)}
        </code>
      );
    }
    return <span key={key}>{part}</span>;
  });
}

export function MarkdownView({ text, className }: { text: string; className?: string }) {
  const blocks = text.replace(/\r\n/g, "\n").split(/\n{2,}/);
  return (
    <div className={cn("space-y-3 text-sm leading-relaxed text-muted", className)}>
      {blocks.map((block, i) => {
        const lines = block.split("\n");
        const first = lines[0] ?? "";
        if (first.startsWith("```")) {
          const body = lines.slice(1).join("\n").replace(/```$/, "");
          return (
            <pre
              key={i}
              className="overflow-x-auto rounded-md bg-subtle p-3 font-mono text-xs text-fg shadow-[var(--shadow-border)]"
            >
              {body}
            </pre>
          );
        }
        if (first.startsWith("# ")) {
          return (
            <h3 key={i} className="font-display text-xl font-medium text-fg">
              {first.slice(2)}
            </h3>
          );
        }
        if (first.startsWith("## ")) {
          return (
            <h4 key={i} className="font-display text-lg font-medium text-fg">
              {first.slice(3)}
            </h4>
          );
        }
        if (first.startsWith("### ")) {
          return (
            <h5 key={i} className="text-sm font-medium text-fg">
              {first.slice(4)}
            </h5>
          );
        }
        if (lines.every((l) => l.trim().startsWith("- ") || l.trim().startsWith("* "))) {
          return (
            <ul key={i} className="space-y-1 pl-4">
              {lines.map((l, j) => (
                <li key={j} className="list-disc">
                  {renderInline(l.replace(/^\s*[-*]\s+/, ""), `${i}-${j}`)}
                </li>
              ))}
            </ul>
          );
        }
        if (lines.every((l) => /^\s*\d+\.\s+/.test(l))) {
          return (
            <ol key={i} className="space-y-1 pl-4">
              {lines.map((l, j) => (
                <li key={j} className="list-decimal">
                  {renderInline(l.replace(/^\s*\d+\.\s+/, ""), `${i}-${j}`)}
                </li>
              ))}
            </ol>
          );
        }
        return (
          <p key={i}>
            {lines.map((line, j) => (
              <span key={j}>
                {j > 0 ? <br /> : null}
                {renderInline(line, `${i}-${j}`)}
              </span>
            ))}
          </p>
        );
      })}
    </div>
  );
}
