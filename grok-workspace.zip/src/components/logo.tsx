import { cn } from "@/lib/utils";

export function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={cn("size-6", className)}
      aria-hidden="true"
      fill="none"
    >
      <rect x="3" y="3" width="7" height="7" rx="1.5" className="fill-fg" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" className="fill-fg/35" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" className="fill-fg/35" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" className="fill-accent" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("flex items-center gap-2", className)}>
      <Mark />
      <span className="font-display text-lg font-medium tracking-tight">Quorum</span>
    </span>
  );
}
