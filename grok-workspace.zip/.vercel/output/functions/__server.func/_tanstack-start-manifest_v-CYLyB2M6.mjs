//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CYLyB2M6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/studio/$id"],
		preloads: ["/assets/index-Dh7W3trw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dh7W3trw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CTOrXuDo.js", "/assets/logo-CT-XnB-r.js"]
	},
	"/studio/$id": {
		filePath: "/workspace/src/routes/studio.$id.tsx",
		children: void 0,
		preloads: ["/assets/studio._id-Cyb_Re9N.js", "/assets/logo-CT-XnB-r.js"]
	}
} });
//#endregion
export { tsrStartManifest };
