import { useEffect } from "react";
import { useSessionStore } from "@/lib/agents/store";

export function HydrateSessions() {
  useEffect(() => {
    const done = () => useSessionStore.getState().setHydrated(true);
    try {
      const result = useSessionStore.persist.rehydrate();
      if (result && typeof result.then === "function") {
        void result.finally(done);
      } else {
        done();
      }
    } catch {
      done();
    }
  }, []);
  return null;
}
