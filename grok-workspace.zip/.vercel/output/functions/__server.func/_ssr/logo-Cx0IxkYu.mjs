import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { i as Slot } from "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { c as addNote, d as useSessionStore, l as appendLog, o as addDecision, r as cn, s as addIssue } from "./router-BNZVNUDC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/logo-Cx0IxkYu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getAiStatus = createServerFn({ method: "POST" }).handler(createSsrRpc("73836497a2c5068bc86388a15c765d89837e61d7a982b8fde0cd7fa90765c53d"));
var runAgentStep = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("Invalid request");
	if (!input.task || typeof input.task !== "string") throw new Error("A brief is required");
	if (![
		"question",
		"spec",
		"plan",
		"build",
		"review",
		"fix"
	].includes(input.step)) throw new Error("Unknown step");
	return {
		...input,
		task: input.task.slice(0, 2e3),
		answer: input.answer?.slice(0, 2e3),
		spec: input.spec?.slice(0, 8e3),
		plan: input.plan?.slice(0, 8e3),
		reviewComments: input.reviewComments?.slice(0, 4e3),
		files: (input.files ?? []).slice(0, 12).map((f) => ({
			path: String(f.path).slice(0, 180),
			content: String(f.content).slice(0, 12e3)
		})),
		interview: (input.interview ?? []).slice(0, 4).map((t) => ({
			question: String(t.question).slice(0, 800),
			answer: String(t.answer).slice(0, 2e3)
		}))
	};
}).handler(createSsrRpc("2543c785f20b277cd34b4a7796efe093eed5be4f1112341a23a72fb8d4171c1a"));
function extractJsonObject(text) {
	const trimmed = text.trim();
	const raw = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1]?.trim() ?? trimmed;
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start === -1 || end === -1 || end <= start) throw new Error("The specialist returned unstructured text.");
	const sliced = raw.slice(start, end + 1);
	try {
		const parsed = JSON.parse(sliced);
		if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Expected a JSON object.");
		return parsed;
	} catch {
		throw new Error("Could not parse the specialist’s reply.");
	}
}
function asString(value) {
	return typeof value === "string" ? value : "";
}
function asStringArray(value) {
	if (!Array.isArray(value)) return [];
	return value.filter((v) => typeof v === "string" && v.trim().length > 0);
}
function extractFiles(payload, fallbackText) {
	const raw = payload.files;
	if (Array.isArray(raw)) {
		const files = [];
		for (const item of raw) {
			if (!item || typeof item !== "object") continue;
			const rec = item;
			const path = asString(rec.path).trim().replace(/^\.?\//, "");
			const content = asString(rec.content);
			if (!path || !content) continue;
			if (path.includes("..") || path.startsWith("/")) continue;
			files.push({
				path,
				content
			});
		}
		if (files.length > 0) return files.slice(0, 12);
	}
	return extractFencedFiles(fallbackText);
}
function extractFencedFiles(text) {
	const files = [];
	const re = /```(?:([\w.+-]+)\s+)?(?:file(?:name)?[:=]\s*)?([^\n`]+)?\n([\s\S]*?)```/gi;
	let match;
	while (match = re.exec(text)) {
		const lang = (match[1] ?? "").trim();
		const maybePath = (match[2] ?? "").trim().replace(/^["']|["']$/g, "");
		const content = (match[3] ?? "").trim();
		if (!content) continue;
		const path = maybePath && /[./]/.test(maybePath) && !maybePath.includes(" ") ? maybePath.replace(/^\.?\//, "") : lang ? `untitled.${langToExt(lang)}` : `untitled-${files.length + 1}.txt`;
		files.push({
			path,
			content
		});
	}
	return files.slice(0, 12);
}
function langToExt(lang) {
	return {
		javascript: "js",
		typescript: "ts",
		tsx: "tsx",
		jsx: "jsx",
		python: "py",
		rust: "rs",
		html: "html",
		css: "css",
		json: "json",
		markdown: "md",
		md: "md",
		bash: "sh",
		shell: "sh"
	}[lang.toLowerCase()] ?? lang.toLowerCase();
}
function mergeFiles(existing, incoming) {
	const map = new Map(existing.map((f) => [f.path, f]));
	for (const file of incoming) map.set(file.path, file);
	return [...map.values()].sort((a, b) => a.path.localeCompare(b.path));
}
function patch(id, fn) {
	useSessionStore.getState().patch(id, fn);
}
function get(id) {
	return useSessionStore.getState().sessions[id];
}
function fail(id, agent, error) {
	patch(id, (s) => ({
		...appendLog(s, agent === "done" ? "review" : agent, "issue", error),
		busy: false,
		error,
		agentStatus: {
			...s.agentStatus,
			[agent === "done" ? "review" : agent]: "error"
		}
	}));
}
async function timed(id, fn) {
	const t0 = performance.now();
	try {
		return await fn();
	} finally {
		const dt = performance.now() - t0;
		patch(id, (s) => ({
			...s,
			stats: {
				calls: s.stats.calls + 1,
				durationMs: s.stats.durationMs + dt
			}
		}));
	}
}
async function askFirstQuestion(id) {
	if (!get(id)) return;
	patch(id, (s) => ({
		...appendLog(s, "brief", "think", "Opening the interview."),
		busy: true,
		error: null,
		agentStatus: {
			...s.agentStatus,
			brief: "thinking"
		}
	}));
	await interviewTurn(id);
}
async function answerQuestion(id, answer) {
	if (!get(id)?.pendingQuestion) return;
	const trimmed = answer.trim();
	if (!trimmed) return;
	patch(id, (s) => {
		if (!s.pendingQuestion) return s;
		const interview = [...s.interview, {
			question: s.pendingQuestion,
			answer: trimmed
		}];
		return {
			...appendLog(s, "brief", "say", trimmed),
			interview,
			pendingQuestion: null,
			busy: true,
			error: null,
			agentStatus: {
				...s.agentStatus,
				brief: "thinking"
			}
		};
	});
	await interviewTurn(id);
}
async function interviewTurn(id) {
	const session = get(id);
	if (!session) return;
	const shouldForceSpec = session.interview.length >= 4;
	const result = await timed(id, () => runAgentStep({ data: {
		step: shouldForceSpec ? "spec" : "question",
		task: session.task,
		interview: session.interview,
		answer: shouldForceSpec ? void 0 : session.interview.at(-1)?.answer
	} }));
	if (!result.ok) {
		fail(id, "brief", result.error);
		return;
	}
	try {
		const json = extractJsonObject(result.text);
		if (asString(json.status) === "ask" && !shouldForceSpec) {
			const question = asString(json.question).trim();
			if (!question) throw new Error("No question returned.");
			patch(id, (s) => ({
				...appendLog(s, "brief", "say", question),
				pendingQuestion: question,
				busy: false,
				agentStatus: {
					...s.agentStatus,
					brief: "waiting"
				}
			}));
			return;
		}
		const spec = asString(json.spec).trim() || asString(json.content).trim();
		if (!spec) throw new Error("The spec came back empty.");
		patch(id, (s) => ({
			...addDecision(appendLog(s, "brief", "decision", "Spec locked."), "Spec written from the interview."),
			spec,
			pendingQuestion: null,
			phase: "plan",
			busy: false,
			agentStatus: {
				...s.agentStatus,
				brief: "done",
				plan: "waiting"
			}
		}));
	} catch (err) {
		const specFallback = result.text.replace(/```json[\s\S]*$/i, "").trim();
		if (specFallback.length > 80 && shouldForceSpec) {
			patch(id, (s) => ({
				...s,
				spec: specFallback,
				phase: "plan",
				busy: false,
				pendingQuestion: null,
				agentStatus: {
					...s.agentStatus,
					brief: "done",
					plan: "waiting"
				}
			}));
			return;
		}
		fail(id, "brief", err instanceof Error ? err.message : "Interview failed.");
	}
}
async function composePlan(id) {
	const session = get(id);
	if (!session?.spec) return;
	patch(id, (s) => ({
		...appendLog(s, "plan", "think", "Drafting the implementation plan."),
		busy: true,
		error: null,
		phase: "plan",
		agentStatus: {
			...s.agentStatus,
			plan: "thinking"
		}
	}));
	const result = await timed(id, () => runAgentStep({ data: {
		step: "plan",
		task: session.task,
		spec: session.spec
	} }));
	if (!result.ok) {
		fail(id, "plan", result.error);
		return;
	}
	patch(id, (s) => ({
		...addDecision(appendLog(s, "plan", "decision", "Plan ready."), "Architecture plan drafted."),
		plan: result.text.trim(),
		phase: "build",
		busy: false,
		agentStatus: {
			...s.agentStatus,
			plan: "done",
			build: "waiting"
		}
	}));
}
async function runBuild(id) {
	const session = get(id);
	if (!session?.plan) return;
	patch(id, (s) => ({
		...appendLog(s, "build", "think", "Writing project files."),
		busy: true,
		error: null,
		phase: "build",
		agentStatus: {
			...s.agentStatus,
			build: "thinking"
		}
	}));
	const result = await timed(id, () => runAgentStep({ data: {
		step: "build",
		task: session.task,
		spec: session.spec,
		plan: session.plan
	} }));
	if (!result.ok) {
		fail(id, "build", result.error);
		return;
	}
	applyBuild(id, result.text, false);
}
async function runReview(id) {
	const session = get(id);
	if (!session?.files.length) return;
	if (session.review.cycles >= 2) {
		patch(id, (s) => ({
			...s,
			review: {
				...s.review,
				approved: true
			},
			phase: "done",
			busy: false,
			agentStatus: {
				...s.agentStatus,
				review: "done"
			}
		}));
		return;
	}
	patch(id, (s) => ({
		...appendLog(s, "review", "think", "Reading the files against the spec."),
		busy: true,
		error: null,
		phase: "review",
		agentStatus: {
			...s.agentStatus,
			review: "thinking"
		}
	}));
	const latest = get(id);
	if (!latest) return;
	const result = await timed(id, () => runAgentStep({ data: {
		step: "review",
		task: latest.task,
		spec: latest.spec,
		plan: latest.plan,
		files: latest.files
	} }));
	if (!result.ok) {
		fail(id, "review", result.error);
		return;
	}
	try {
		const json = extractJsonObject(result.text);
		const verdict = asString(json.verdict).toLowerCase();
		const summary = asString(json.summary).trim() || result.text;
		const issues = asStringArray(json.issues);
		const approved = verdict === "approved";
		patch(id, (s) => {
			let next = appendLog(s, "review", approved ? "decision" : "issue", summary);
			for (const issue of issues) next = addIssue(next, issue);
			if (approved) next = addDecision(next, "Review approved the build.");
			return {
				...next,
				review: {
					cycles: s.review.cycles + 1,
					comments: summary,
					approved,
					issues,
					pendingFix: !approved
				},
				phase: approved ? "done" : "review",
				busy: false,
				agentStatus: {
					...s.agentStatus,
					review: approved ? "done" : "waiting",
					build: approved ? "done" : "waiting"
				}
			};
		});
	} catch (err) {
		fail(id, "review", err instanceof Error ? err.message : "Review failed.");
	}
}
async function applyFixes(id) {
	const session = get(id);
	if (!session?.review.comments || session.review.approved) return;
	patch(id, (s) => ({
		...appendLog(s, "build", "think", "Applying review notes."),
		busy: true,
		error: null,
		phase: "build",
		agentStatus: {
			...s.agentStatus,
			build: "thinking",
			review: "idle"
		}
	}));
	const latest = get(id);
	if (!latest) return;
	const result = await timed(id, () => runAgentStep({ data: {
		step: "fix",
		task: latest.task,
		spec: latest.spec,
		plan: latest.plan,
		files: latest.files,
		reviewComments: latest.review.comments
	} }));
	if (!result.ok) {
		fail(id, "build", result.error);
		return;
	}
	applyBuild(id, result.text, true);
}
function applyBuild(id, text, fromFix) {
	try {
		const json = extractJsonObject(text);
		const files = extractFiles(json, text);
		if (files.length === 0) throw new Error("No files were returned.");
		const summary = asString(json.summary).trim();
		patch(id, (s) => {
			const merged = fromFix ? mergeFiles(s.files, files) : files;
			let next = appendLog(s, "build", "file", `${merged.length} files on the board.`);
			if (summary) next = addNote(next, summary);
			next = addDecision(next, fromFix ? "Build applied review fixes." : "First build landed.");
			return {
				...next,
				files: merged,
				review: fromFix ? {
					...s.review,
					pendingFix: false
				} : s.review,
				phase: "review",
				busy: false,
				error: null,
				agentStatus: {
					...s.agentStatus,
					build: "done",
					review: "waiting"
				}
			};
		});
	} catch (err) {
		fail(id, "build", err instanceof Error ? err.message : "Build failed.");
	}
}
async function retryLast(id) {
	const s = get(id);
	if (!s) return;
	patch(id, (cur) => ({
		...cur,
		error: null
	}));
	if (!s.spec && s.phase === "brief") {
		await interviewTurn(id);
		return;
	}
	if (s.phase === "plan" && !s.plan) {
		await composePlan(id);
		return;
	}
	if ((s.phase === "build" || s.phase === "review") && s.files.length === 0) {
		await runBuild(id);
		return;
	}
	if (s.phase === "review" && !s.review.comments) await runReview(id);
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-subtle text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-subtle",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-subtle",
			danger: "bg-transparent text-danger hover:bg-subtle"
		},
		size: {
			default: "h-11 min-h-11 px-4",
			sm: "h-9 min-h-9 px-3 text-xs",
			lg: "h-12 min-h-12 px-5",
			icon: "size-11 min-h-11 min-w-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-28 w-full rounded-md bg-subtle px-3 py-3 text-sm text-fg shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 placeholder:text-faint hover:shadow-[var(--shadow-border-hover)] focus-visible:outline-none focus-visible:shadow-[0_0_0_1px_var(--color-accent)] disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className: cn("size-6", className),
		"aria-hidden": "true",
		fill: "none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3",
				y: "3",
				width: "7",
				height: "7",
				rx: "1.5",
				className: "fill-fg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "14",
				y: "3",
				width: "7",
				height: "7",
				rx: "1.5",
				className: "fill-fg/35"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3",
				y: "14",
				width: "7",
				height: "7",
				rx: "1.5",
				className: "fill-fg/35"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "14",
				y: "14",
				width: "7",
				height: "7",
				rx: "1.5",
				className: "fill-accent"
			})
		]
	});
}
function Wordmark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("flex items-center gap-2", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-lg font-medium tracking-tight",
			children: "Quorum"
		})]
	});
}
//#endregion
export { applyFixes as a, getAiStatus as c, runReview as d, answerQuestion as i, retryLast as l, Textarea as n, askFirstQuestion as o, Wordmark as r, composePlan as s, Button as t, runBuild as u };
