import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Clock3, u as ArrowRight } from "../_libs/lucide-react.mjs";
import { a as truncate, d as useSessionStore, f as AGENT_META, i as formatRelative } from "./router-BNZVNUDC.mjs";
import { c as getAiStatus, n as Textarea, o as askFirstQuestion, r as Wordmark, t as Button } from "./logo-Cx0IxkYu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BAD31_iB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EXAMPLES = [
	{
		label: "Habit tracker",
		task: "Build a single-page habit tracker with daily checkboxes, streaks, and local persistence."
	},
	{
		label: "Pomodoro",
		task: "Build a pomodoro timer with focus and break modes, a session log, and keyboard shortcuts."
	},
	{
		label: "Markdown notes",
		task: "Build a markdown notes app with a file list, live preview, and tag filter."
	}
];
var STEPS = [
	{
		id: "brief",
		caption: "Interview, then a spec."
	},
	{
		id: "plan",
		caption: "Architecture and file map."
	},
	{
		id: "build",
		caption: "A small, complete project."
	},
	{
		id: "review",
		caption: "Critic reads every file."
	}
];
function HomePage() {
	const navigate = useNavigate();
	const hydrated = useSessionStore((s) => s.hydrated);
	const order = useSessionStore((s) => s.order);
	const sessionsMap = useSessionStore((s) => s.sessions);
	const startSession = useSessionStore((s) => s.startSession);
	const sessions = order.map((id) => sessionsMap[id]).filter((s) => Boolean(s));
	const [task, setTask] = (0, import_react.useState)("");
	const [opening, setOpening] = (0, import_react.useState)(false);
	const [ai, setAi] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getAiStatus().then((r) => setAi(r.available));
	}, []);
	async function openSession(brief) {
		const trimmed = brief.trim();
		if (!trimmed || opening) return;
		setOpening(true);
		const session = startSession(trimmed);
		navigate({
			to: "/studio/$id",
			params: { id: session.id }
		});
		askFirstQuestion(session.id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mx-auto flex w-full max-w-5xl items-center justify-between px-5 py-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden text-xs text-faint sm:block",
				children: "Sessions stay on this device"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto w-full max-w-5xl px-5 pb-20 pt-6 sm:pt-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "stagger-in text-xs font-medium uppercase tracking-[0.18em] text-faint",
					children: "Multi-agent studio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "stagger-in mt-4 max-w-2xl font-display text-4xl font-medium tracking-tight text-fg sm:text-6xl",
					children: ["Four specialists.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-muted",
						children: "One brief."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "stagger-in mt-5 max-w-xl text-base text-muted",
					children: "Quorum interviews you, drafts the plan, writes the files, and reviews the result — then hands the project back."
				}),
				ai === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "stagger-in mt-4 text-sm text-warn",
					children: "AI is not available in this environment. You can still browse the studio, but sessions cannot run."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "stagger-in mt-10 rounded-xl bg-elevated p-3 shadow-[var(--shadow-border)] sm:p-4",
					onSubmit: (e) => {
						e.preventDefault();
						openSession(task);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "brief",
							className: "px-1 text-xs font-medium uppercase tracking-[0.14em] text-faint",
							children: "Brief"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "brief",
							value: task,
							onChange: (e) => setTask(e.target.value),
							onKeyDown: (e) => {
								if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
									e.preventDefault();
									openSession(task);
								}
							},
							placeholder: "Describe the software you want built…",
							className: "mt-2 min-h-32 resize-y bg-bg",
							disabled: opening || ai === false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: EXAMPLES.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 rounded-full bg-subtle px-3 text-xs text-muted transition-colors duration-150 hover:text-fg",
									onClick: () => setTask(ex.task),
									children: ex.label
								}, ex.label))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "submit",
								disabled: !task.trim() || opening || ai === false,
								className: "w-full sm:w-auto",
								children: ["Open a session", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-medium uppercase tracking-[0.14em] text-faint",
						children: "How a session runs"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
						children: STEPS.map((step) => {
							const meta = AGENT_META[step.id];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-lg bg-elevated p-4 shadow-[var(--shadow-border)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs tabular-nums text-faint",
										children: meta.index
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 font-display text-xl font-medium text-fg",
										children: meta.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: meta.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm text-muted",
										children: step.caption
									})
								]
							}, step.id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-medium uppercase tracking-[0.14em] text-faint",
						children: "Recent sessions"
					}), !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-faint",
						children: "Loading sessions…"
					}) : sessions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted",
						children: "No sessions yet. Open one with a brief above."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-border rounded-lg bg-elevated shadow-[var(--shadow-border)]",
						children: sessions.slice(0, 8).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/studio/$id",
							params: { id: s.id },
							className: "flex items-center justify-between gap-4 px-4 py-3.5 transition-colors duration-150 hover:bg-subtle",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm text-fg",
									children: truncate(s.task, 90)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-0.5 flex items-center gap-1.5 text-xs text-faint",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-3" }),
										formatRelative(s.updatedAt),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-border-strong",
											children: "·"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "capitalize",
											children: s.phase
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 shrink-0 text-faint" })]
						}) }, s.id))
					})]
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {});
}
//#endregion
export { Home as component };
