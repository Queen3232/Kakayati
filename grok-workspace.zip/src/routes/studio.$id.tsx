import { createFileRoute } from "@tanstack/react-router";
import { StudioPage } from "@/components/studio/studio-page";

export const Route = createFileRoute("/studio/$id")({
  component: Studio,
});

function Studio() {
  const { id } = Route.useParams();
  return <StudioPage id={id} />;
}
