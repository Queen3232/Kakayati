import { useState } from "react";
import { ArrowRight, RotateCcw } from "lucide-react";
import type { Session } from "@/lib/agents/types";
import {
  answerQuestion,
  applyFixes,
  composePlan,
  retryLast,
  runBuild,
  runReview,
} from "@/lib/agents/run";
import { MAX_INTERVIEW, MAX_REVIEW_CYCLES } from "@/lib/agents/types";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { MarkdownView } from "@/components/markdown-view";

export function WorkPanel({ session }: { session: Session }) {
  return (
    <div className="space-y-8">
      {session.error ? (
        <div className="rounded-lg bg-subtle px-4 py-3 shadow-[var(--shadow-border)]">
          <p className="text-sm text-danger">{session.error}</p>
          <Button
            variant="outline"
            size="sm"
            className="mt-3"
            disabled={session.busy}
            onClick={() => void retryLast(session.id)}
          >
            <RotateCcw />
            Try again
          </Button>
        </div>
      ) : null}

      <BriefSection session={session} />
      {session.spec ? <PlanSection session={session} /> : null}
      {session.plan ? <BuildSection session={session} /> : null}
      {session.files.length > 0 ? <ReviewSection session={session} /> : null}
    </div>
  );
}

function BriefSection({ session }: { session: Session }) {
  const [answer, setAnswer] = useState("");
  const waiting = Boolean(session.pendingQuestion) && !session.busy;

  return (
    <section>
      <Header kicker="01" title="Brief" hint="Analyst" />
      <p className="mt-3 text-sm text-muted">{session.task}</p>

      {session.interview.length > 0 ? (
        <ol className="mt-5 space-y-4">
          {session.interview.map((turn, i) => (
            <li key={i} className="grid gap-2">
              <p className="text-sm text-fg">{turn.question}</p>
              <p className="rounded-md bg-subtle px-3 py-2 text-sm text-muted">{turn.answer}</p>
            </li>
          ))}
        </ol>
      ) : null}

      {session.pendingQuestion ? (
        <div className="mt-5 rounded-lg bg-elevated p-4 shadow-[var(--shadow-border)]">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-faint">
            Question {session.interview.length + 1} of {MAX_INTERVIEW}
          </p>
          <p className="mt-2 text-base text-fg">{session.pendingQuestion}</p>
          <form
            className="mt-4 space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              const next = answer.trim();
              if (!next) return;
              setAnswer("");
              void answerQuestion(session.id, next);
            }}
          >
            <Textarea
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              onKeyDown={(e) => {
                if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
                  e.preventDefault();
                  const next = answer.trim();
                  if (!next || !waiting) return;
                  setAnswer("");
                  void answerQuestion(session.id, next);
                }
              }}
              placeholder="Answer here…"
              disabled={!waiting}
              className="min-h-24 bg-bg"
            />
            <Button type="submit" disabled={!waiting || !answer.trim()} className="w-full sm:w-auto">
              Send answer
              <ArrowRight />
            </Button>
          </form>
        </div>
      ) : null}

      {session.busy && session.agentStatus.brief === "thinking" ? (
        <p className="shimmer-text mt-4 text-sm">Listening…</p>
      ) : null}

      {session.spec ? (
        <div className="mt-6">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-faint">Spec</p>
          <div className="mt-3 rounded-lg bg-elevated p-4 shadow-[var(--shadow-border)]">
            <MarkdownView text={session.spec} />
          </div>
        </div>
      ) : null}
    </section>
  );
}

function PlanSection({ session }: { session: Session }) {
  const ready = !session.plan && !session.busy && Boolean(session.spec);
  return (
    <section>
      <Header kicker="02" title="Plan" hint="Architect" />
      {session.plan ? (
        <div className="mt-4 rounded-lg bg-elevated p-4 shadow-[var(--shadow-border)]">
          <MarkdownView text={session.plan} />
        </div>
      ) : (
        <div className="mt-4">
          {session.busy && session.agentStatus.plan === "thinking" ? (
            <p className="shimmer-text text-sm">Drafting the plan…</p>
          ) : (
            <Button disabled={!ready} onClick={() => void composePlan(session.id)}>
              Compose the plan
              <ArrowRight />
            </Button>
          )}
        </div>
      )}
    </section>
  );
}

function BuildSection({ session }: { session: Session }) {
  const ready = session.files.length === 0 && !session.busy && Boolean(session.plan);
  return (
    <section>
      <Header kicker="03" title="Build" hint="Engineer" />
      {session.files.length > 0 ? (
        <p className="mt-3 text-sm text-muted">
          {session.files.length} files on the board. Open the Files tab to read them.
        </p>
      ) : session.busy && session.agentStatus.build === "thinking" ? (
        <p className="shimmer-text mt-3 text-sm">Writing files…</p>
      ) : (
        <Button className="mt-4" disabled={!ready} onClick={() => void runBuild(session.id)}>
          Build the project
          <ArrowRight />
        </Button>
      )}
    </section>
  );
}

function ReviewSection({ session }: { session: Session }) {
  const { review } = session;
  const canReview =
    !session.busy && session.files.length > 0 && !review.approved && !review.pendingFix;
  const canFix = !session.busy && review.pendingFix && review.cycles <= MAX_REVIEW_CYCLES;

  return (
    <section>
      <Header kicker="04" title="Review" hint="Critic" />
      {review.comments ? (
        <div className="mt-4 rounded-lg bg-elevated p-4 shadow-[var(--shadow-border)]">
          <Badge variant={review.approved ? "ok" : "warn"}>
            {review.approved ? "Approved" : "Changes requested"}
          </Badge>
          <p className="mt-3 text-sm text-muted">{review.comments}</p>
          {review.issues.length > 0 ? (
            <ul className="mt-3 space-y-1">
              {review.issues.map((issue) => (
                <li key={issue} className="text-sm text-danger">
                  {issue}
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      ) : null}

      {session.busy && session.agentStatus.review === "thinking" ? (
        <p className="shimmer-text mt-3 text-sm">Reading the files…</p>
      ) : null}

      <div className="mt-4 flex flex-wrap gap-2">
        {canReview ? (
          <Button onClick={() => void runReview(session.id)}>
            Run review
            <ArrowRight />
          </Button>
        ) : null}
        {canFix ? (
          <Button onClick={() => void applyFixes(session.id)}>
            Apply fixes
            <ArrowRight />
          </Button>
        ) : null}
        {review.approved ? (
          <p className="text-sm text-ok">The critic signed off. Export the files when you are ready.</p>
        ) : null}
      </div>
    </section>
  );
}

function Header({ kicker, title, hint }: { kicker: string; title: string; hint: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <h2 className="font-display text-2xl font-medium text-fg">{title}</h2>
      <p className="font-mono text-[11px] tabular-nums text-faint">
        {kicker} · {hint}
      </p>
    </div>
  );
}
