import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { AgentId, LogEntry, Session } from "./types";
import { createSession } from "./types";

interface SessionState {
  sessions: Record<string, Session>;
  order: string[];
  hydrated: boolean;
  setHydrated: (v: boolean) => void;
  startSession: (task: string) => Session;
  patch: (id: string, fn: (s: Session) => Session) => void;
  remove: (id: string) => void;
  list: () => Session[];
}

function touch(s: Session): Session {
  return { ...s, updatedAt: new Date().toISOString() };
}

export const useSessionStore = create<SessionState>()(
  persist(
    (set, get) => ({
      sessions: {},
      order: [],
      hydrated: false,
      setHydrated: (v) => set({ hydrated: v }),
      startSession: (task: string) => {
        const session = createSession(task);
        set((st) => ({
          sessions: { ...st.sessions, [session.id]: session },
          order: [session.id, ...st.order.filter((id) => id !== session.id)],
        }));
        return session;
      },
      patch: (id, fn) => {
        set((st) => {
          const current = st.sessions[id];
          if (!current) return st;
          const next = touch(fn(current));
          return { sessions: { ...st.sessions, [id]: next } };
        });
      },
      remove: (id) => {
        set((st) => {
          const { [id]: _, ...rest } = st.sessions;
          return { sessions: rest, order: st.order.filter((x) => x !== id) };
        });
      },
      list: () => {
        const { sessions, order } = get();
        return order.map((id) => sessions[id]).filter(Boolean) as Session[];
      },
    }),
    {
      name: "quorum-sessions-v1",
      skipHydration: true,
      partialize: (s) => ({
        sessions: s.sessions,
        order: s.order,
      }),
    },
  ),
);

export function useSession(id: string | undefined): Session | undefined {
  return useSessionStore((s) => (id ? s.sessions[id] : undefined));
}

export function appendLog(s: Session, agent: AgentId, kind: LogEntry["kind"], text: string): Session {
  const entry: LogEntry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    at: new Date().toISOString(),
    agent,
    kind,
    text,
  };
  return { ...s, log: [...s.log, entry].slice(-48) };
}

export function addNote(s: Session, note: string): Session {
  const notes = [...s.blackboard.notes, note].slice(-12);
  return { ...s, blackboard: { ...s.blackboard, notes } };
}

export function addDecision(s: Session, decision: string): Session {
  const decisions = [...s.blackboard.decisions, decision].slice(-12);
  return { ...s, blackboard: { ...s.blackboard, decisions } };
}

export function addIssue(s: Session, issue: string): Session {
  const issues = [...s.blackboard.issues, issue].slice(-12);
  return { ...s, blackboard: { ...s.blackboard, issues } };
}
