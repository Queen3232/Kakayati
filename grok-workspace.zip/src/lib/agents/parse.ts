import type { ProjectFile } from "./types";

export function extractJsonObject(text: string): Record<string, unknown> {
  const trimmed = text.trim();
  const fence = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const raw = fence?.[1]?.trim() ?? trimmed;
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) {
    throw new Error("The specialist returned unstructured text.");
  }
  const sliced = raw.slice(start, end + 1);
  try {
    const parsed: unknown = JSON.parse(sliced);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("Expected a JSON object.");
    }
    return parsed as Record<string, unknown>;
  } catch {
    throw new Error("Could not parse the specialist’s reply.");
  }
}

export function asString(value: unknown): string {
  return typeof value === "string" ? value : "";
}

export function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((v): v is string => typeof v === "string" && v.trim().length > 0);
}

export function extractFiles(payload: Record<string, unknown>, fallbackText: string): ProjectFile[] {
  const raw = payload.files;
  if (Array.isArray(raw)) {
    const files: ProjectFile[] = [];
    for (const item of raw) {
      if (!item || typeof item !== "object") continue;
      const rec = item as Record<string, unknown>;
      const path = asString(rec.path).trim().replace(/^\.?\//, "");
      const content = asString(rec.content);
      if (!path || !content) continue;
      if (path.includes("..") || path.startsWith("/")) continue;
      files.push({ path, content });
    }
    if (files.length > 0) return files.slice(0, 12);
  }
  return extractFencedFiles(fallbackText);
}

export function extractFencedFiles(text: string): ProjectFile[] {
  const files: ProjectFile[] = [];
  const re = /```(?:([\w.+-]+)\s+)?(?:file(?:name)?[:=]\s*)?([^\n`]+)?\n([\s\S]*?)```/gi;
  let match: RegExpExecArray | null;
  while ((match = re.exec(text))) {
    const lang = (match[1] ?? "").trim();
    const maybePath = (match[2] ?? "").trim().replace(/^["']|["']$/g, "");
    const content = (match[3] ?? "").trim();
    if (!content) continue;
    const path =
      maybePath && /[./]/.test(maybePath) && !maybePath.includes(" ")
        ? maybePath.replace(/^\.?\//, "")
        : lang
          ? `untitled.${langToExt(lang)}`
          : `untitled-${files.length + 1}.txt`;
    files.push({ path, content });
  }
  return files.slice(0, 12);
}

function langToExt(lang: string): string {
  const map: Record<string, string> = {
    javascript: "js",
    typescript: "ts",
    tsx: "tsx",
    jsx: "jsx",
    python: "py",
    rust: "rs",
    html: "html",
    css: "css",
    json: "json",
    markdown: "md",
    md: "md",
    bash: "sh",
    shell: "sh",
  };
  return map[lang.toLowerCase()] ?? lang.toLowerCase();
}

export function mergeFiles(existing: ProjectFile[], incoming: ProjectFile[]): ProjectFile[] {
  const map = new Map(existing.map((f) => [f.path, f]));
  for (const file of incoming) {
    map.set(file.path, file);
  }
  return [...map.values()].sort((a, b) => a.path.localeCompare(b.path));
}
