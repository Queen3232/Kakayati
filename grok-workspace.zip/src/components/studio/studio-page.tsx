import { useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, LayoutGrid, ListTree, Users } from "lucide-react";
import { useSession, useSessionStore } from "@/lib/agents/store";
import { exportSession } from "@/lib/agents/export";
import { truncate } from "@/lib/utils";
import { Wordmark } from "@/components/logo";
import { PhaseBar } from "@/components/studio/phase-bar";
import { AgentRoster } from "@/components/studio/agent-roster";
import { BlackboardPanel } from "@/components/studio/blackboard-panel";
import { FilesPanel } from "@/components/studio/files-panel";
import { WorkPanel } from "@/components/studio/work-panel";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

type MobileTab = "work" | "crew" | "files";

export function StudioPage({ id }: { id: string }) {
  const session = useSession(id);
  const hydrated = useSessionStore((s) => s.hydrated);
  const [tab, setTab] = useState<MobileTab>("work");

  if (!hydrated) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-bg text-sm text-muted">
        Restoring session…
      </div>
    );
  }

  if (!session) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-fg">
        <p className="font-display text-2xl">Session not found</p>
        <p className="max-w-sm text-sm text-muted">
          It may have been cleared from this device. Open a new one from the studio home.
        </p>
        <Link to="/" className="mt-2 text-sm text-fg underline decoration-border underline-offset-4">
          Back to Quorum
        </Link>
      </div>
    );
  }

  const duration = Math.round(session.stats.durationMs / 1000);

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="flex items-center gap-3 border-b border-border px-4 py-3 sm:px-5">
        <Link
          to="/"
          className="inline-flex size-11 items-center justify-center rounded-md text-muted hover:bg-subtle hover:text-fg lg:hidden"
          aria-label="Back"
        >
          <ArrowLeft className="size-4" />
        </Link>
        <Link to="/" className="hidden lg:block">
          <Wordmark />
        </Link>
        <span className="hidden h-5 w-px bg-border lg:block" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm text-fg">{truncate(session.task, 80)}</p>
          <p className="text-xs tabular-nums text-faint">
            {session.stats.calls} calls
            {duration > 0 ? ` · ${duration}s` : ""}
          </p>
        </div>
      </header>

      <div className="border-b border-border px-4 py-2 sm:px-5">
        <PhaseBar phase={session.phase} />
      </div>

      <div className="mx-auto hidden min-h-0 w-full max-w-[1400px] flex-1 grid-cols-[220px_minmax(0,1fr)_320px] gap-0 overflow-hidden lg:grid">
        <aside className="min-h-0 border-r border-border p-4">
          <AgentRoster session={session} />
        </aside>
        <ScrollArea className="min-h-0">
          <div className="px-6 py-6">
            <WorkPanel session={session} />
          </div>
        </ScrollArea>
        <aside className="flex min-h-0 flex-col border-l border-border">
          <ScrollArea className="max-h-[40%] border-b border-border p-4">
            <BlackboardPanel session={session} />
          </ScrollArea>
          <div className="flex min-h-0 flex-1 flex-col p-3">
            <FilesPanel files={session.files} onExport={() => exportSession(session)} />
          </div>
        </aside>
      </div>

      <div className="flex min-h-0 flex-1 flex-col lg:hidden">
        <ScrollArea className="min-h-0 flex-1">
          <div className="px-4 py-5 pb-24">
            {tab === "work" ? <WorkPanel session={session} /> : null}
            {tab === "crew" ? (
              <div className="space-y-8">
                <AgentRoster session={session} />
                <BlackboardPanel session={session} />
              </div>
            ) : null}
            {tab === "files" ? (
              <FilesPanel files={session.files} onExport={() => exportSession(session)} />
            ) : null}
          </div>
        </ScrollArea>
        <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)]">
          <ul className="mx-auto grid max-w-lg grid-cols-3">
            <MobileTabBtn
              active={tab === "work"}
              onClick={() => setTab("work")}
              icon={<LayoutGrid className="size-4" />}
              label="Work"
            />
            <MobileTabBtn
              active={tab === "crew"}
              onClick={() => setTab("crew")}
              icon={<Users className="size-4" />}
              label="Crew"
            />
            <MobileTabBtn
              active={tab === "files"}
              onClick={() => setTab("files")}
              icon={<ListTree className="size-4" />}
              label="Files"
            />
          </ul>
        </nav>
      </div>
    </div>
  );
}

function MobileTabBtn({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
  label: string;
}) {
  return (
    <li>
      <button
        type="button"
        onClick={onClick}
        className={cn(
          "flex h-14 w-full flex-col items-center justify-center gap-1 text-[11px]",
          active ? "text-fg" : "text-faint",
        )}
      >
        {icon}
        {label}
      </button>
    </li>
  );
}
