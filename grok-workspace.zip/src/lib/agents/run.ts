import { runAgentStep } from "./api";
import {
  asString,
  asStringArray,
  extractFiles,
  extractJsonObject,
  mergeFiles,
} from "./parse";
import { addDecision, addIssue, addNote, appendLog, useSessionStore } from "./store";
import { MAX_INTERVIEW, MAX_REVIEW_CYCLES, type Session } from "./types";

function patch(id: string, fn: (s: Session) => Session) {
  useSessionStore.getState().patch(id, fn);
}

function get(id: string): Session | undefined {
  return useSessionStore.getState().sessions[id];
}

function fail(id: string, agent: Session["phase"], error: string) {
  patch(id, (s) => ({
    ...appendLog(s, agent === "done" ? "review" : agent, "issue", error),
    busy: false,
    error,
    agentStatus: { ...s.agentStatus, [agent === "done" ? "review" : agent]: "error" },
  }));
}

async function timed<T>(id: string, fn: () => Promise<T>): Promise<T> {
  const t0 = performance.now();
  try {
    return await fn();
  } finally {
    const dt = performance.now() - t0;
    patch(id, (s) => ({
      ...s,
      stats: { calls: s.stats.calls + 1, durationMs: s.stats.durationMs + dt },
    }));
  }
}

export async function askFirstQuestion(id: string): Promise<void> {
  const session = get(id);
  if (!session) return;
  patch(id, (s) => ({
    ...appendLog(s, "brief", "think", "Opening the interview."),
    busy: true,
    error: null,
    agentStatus: { ...s.agentStatus, brief: "thinking" },
  }));
  await interviewTurn(id);
}

export async function answerQuestion(id: string, answer: string): Promise<void> {
  const session = get(id);
  if (!session?.pendingQuestion) return;
  const trimmed = answer.trim();
  if (!trimmed) return;
  patch(id, (s) => {
    if (!s.pendingQuestion) return s;
    const interview = [...s.interview, { question: s.pendingQuestion, answer: trimmed }];
    return {
      ...appendLog(s, "brief", "say", trimmed),
      interview,
      pendingQuestion: null,
      busy: true,
      error: null,
      agentStatus: { ...s.agentStatus, brief: "thinking" },
    };
  });
  await interviewTurn(id);
}

async function interviewTurn(id: string): Promise<void> {
  const session = get(id);
  if (!session) return;

  const shouldForceSpec = session.interview.length >= MAX_INTERVIEW;
  const result = await timed(id, () =>
    runAgentStep({
      data: {
        step: shouldForceSpec ? "spec" : "question",
        task: session.task,
        interview: session.interview,
        answer: shouldForceSpec ? undefined : session.interview.at(-1)?.answer,
      },
    }),
  );

  if (!result.ok) {
    fail(id, "brief", result.error);
    return;
  }

  try {
    const json = extractJsonObject(result.text);
    const status = asString(json.status);
    if (status === "ask" && !shouldForceSpec) {
      const question = asString(json.question).trim();
      if (!question) throw new Error("No question returned.");
      patch(id, (s) => ({
        ...appendLog(s, "brief", "say", question),
        pendingQuestion: question,
        busy: false,
        agentStatus: { ...s.agentStatus, brief: "waiting" },
      }));
      return;
    }
    const spec = asString(json.spec).trim() || asString(json.content).trim();
    if (!spec) throw new Error("The spec came back empty.");
    patch(id, (s) => ({
      ...addDecision(appendLog(s, "brief", "decision", "Spec locked."), "Spec written from the interview."),
      spec,
      pendingQuestion: null,
      phase: "plan",
      busy: false,
      agentStatus: { ...s.agentStatus, brief: "done", plan: "waiting" },
    }));
  } catch (err) {
    const specFallback = result.text.replace(/```json[\s\S]*$/i, "").trim();
    if (specFallback.length > 80 && shouldForceSpec) {
      patch(id, (s) => ({
        ...s,
        spec: specFallback,
        phase: "plan",
        busy: false,
        pendingQuestion: null,
        agentStatus: { ...s.agentStatus, brief: "done", plan: "waiting" },
      }));
      return;
    }
    fail(id, "brief", err instanceof Error ? err.message : "Interview failed.");
  }
}

export async function composePlan(id: string): Promise<void> {
  const session = get(id);
  if (!session?.spec) return;
  patch(id, (s) => ({
    ...appendLog(s, "plan", "think", "Drafting the implementation plan."),
    busy: true,
    error: null,
    phase: "plan",
    agentStatus: { ...s.agentStatus, plan: "thinking" },
  }));
  const result = await timed(id, () =>
    runAgentStep({
      data: { step: "plan", task: session.task, spec: session.spec },
    }),
  );
  if (!result.ok) {
    fail(id, "plan", result.error);
    return;
  }
  patch(id, (s) => ({
    ...addDecision(appendLog(s, "plan", "decision", "Plan ready."), "Architecture plan drafted."),
    plan: result.text.trim(),
    phase: "build",
    busy: false,
    agentStatus: { ...s.agentStatus, plan: "done", build: "waiting" },
  }));
}

export async function runBuild(id: string): Promise<void> {
  const session = get(id);
  if (!session?.plan) return;
  patch(id, (s) => ({
    ...appendLog(s, "build", "think", "Writing project files."),
    busy: true,
    error: null,
    phase: "build",
    agentStatus: { ...s.agentStatus, build: "thinking" },
  }));
  const result = await timed(id, () =>
    runAgentStep({
      data: {
        step: "build",
        task: session.task,
        spec: session.spec,
        plan: session.plan,
      },
    }),
  );
  if (!result.ok) {
    fail(id, "build", result.error);
    return;
  }
  applyBuild(id, result.text, false);
}

export async function runReview(id: string): Promise<void> {
  const session = get(id);
  if (!session?.files.length) return;
  if (session.review.cycles >= MAX_REVIEW_CYCLES) {
    patch(id, (s) => ({
      ...s,
      review: { ...s.review, approved: true },
      phase: "done",
      busy: false,
      agentStatus: { ...s.agentStatus, review: "done" },
    }));
    return;
  }
  patch(id, (s) => ({
    ...appendLog(s, "review", "think", "Reading the files against the spec."),
    busy: true,
    error: null,
    phase: "review",
    agentStatus: { ...s.agentStatus, review: "thinking" },
  }));
  const latest = get(id);
  if (!latest) return;
  const result = await timed(id, () =>
    runAgentStep({
      data: {
        step: "review",
        task: latest.task,
        spec: latest.spec,
        plan: latest.plan,
        files: latest.files,
      },
    }),
  );
  if (!result.ok) {
    fail(id, "review", result.error);
    return;
  }
  try {
    const json = extractJsonObject(result.text);
    const verdict = asString(json.verdict).toLowerCase();
    const summary = asString(json.summary).trim() || result.text;
    const issues = asStringArray(json.issues);
    const approved = verdict === "approved";
    patch(id, (s) => {
      let next = appendLog(s, "review", approved ? "decision" : "issue", summary);
      for (const issue of issues) next = addIssue(next, issue);
      if (approved) next = addDecision(next, "Review approved the build.");
      return {
        ...next,
        review: {
          cycles: s.review.cycles + 1,
          comments: summary,
          approved,
          issues,
          pendingFix: !approved,
        },
        phase: approved ? "done" : "review",
        busy: false,
        agentStatus: {
          ...s.agentStatus,
          review: approved ? "done" : "waiting",
          build: approved ? "done" : "waiting",
        },
      };
    });
  } catch (err) {
    fail(id, "review", err instanceof Error ? err.message : "Review failed.");
  }
}

export async function applyFixes(id: string): Promise<void> {
  const session = get(id);
  if (!session?.review.comments || session.review.approved) return;
  patch(id, (s) => ({
    ...appendLog(s, "build", "think", "Applying review notes."),
    busy: true,
    error: null,
    phase: "build",
    agentStatus: { ...s.agentStatus, build: "thinking", review: "idle" },
  }));
  const latest = get(id);
  if (!latest) return;
  const result = await timed(id, () =>
    runAgentStep({
      data: {
        step: "fix",
        task: latest.task,
        spec: latest.spec,
        plan: latest.plan,
        files: latest.files,
        reviewComments: latest.review.comments,
      },
    }),
  );
  if (!result.ok) {
    fail(id, "build", result.error);
    return;
  }
  applyBuild(id, result.text, true);
}

function applyBuild(id: string, text: string, fromFix: boolean) {
  try {
    const json = extractJsonObject(text);
    const files = extractFiles(json, text);
    if (files.length === 0) throw new Error("No files were returned.");
    const summary = asString(json.summary).trim();
    patch(id, (s) => {
      const merged = fromFix ? mergeFiles(s.files, files) : files;
      let next = appendLog(s, "build", "file", `${merged.length} files on the board.`);
      if (summary) next = addNote(next, summary);
      next = addDecision(next, fromFix ? "Build applied review fixes." : "First build landed.");
      return {
        ...next,
        files: merged,
        review: fromFix ? { ...s.review, pendingFix: false } : s.review,
        phase: "review",
        busy: false,
        error: null,
        agentStatus: { ...s.agentStatus, build: "done", review: "waiting" },
      };
    });
  } catch (err) {
    fail(id, "build", err instanceof Error ? err.message : "Build failed.");
  }
}

export async function retryLast(id: string): Promise<void> {
  const s = get(id);
  if (!s) return;
  patch(id, (cur) => ({ ...cur, error: null }));
  if (!s.spec && s.phase === "brief") {
    await interviewTurn(id);
    return;
  }
  if (s.phase === "plan" && !s.plan) {
    await composePlan(id);
    return;
  }
  if ((s.phase === "build" || s.phase === "review") && s.files.length === 0) {
    await runBuild(id);
    return;
  }
  if (s.phase === "review" && !s.review.comments) {
    await runReview(id);
  }
}
