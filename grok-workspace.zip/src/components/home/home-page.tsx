import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Clock3 } from "lucide-react";
import { getAiStatus } from "@/lib/agents/api";
import { askFirstQuestion } from "@/lib/agents/run";
import { useSessionStore } from "@/lib/agents/store";
import { AGENT_META, type AgentId } from "@/lib/agents/types";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Wordmark } from "@/components/logo";
import { formatRelative, truncate } from "@/lib/utils";

const EXAMPLES = [
  {
    label: "Habit tracker",
    task: "Build a single-page habit tracker with daily checkboxes, streaks, and local persistence.",
  },
  {
    label: "Pomodoro",
    task: "Build a pomodoro timer with focus and break modes, a session log, and keyboard shortcuts.",
  },
  {
    label: "Markdown notes",
    task: "Build a markdown notes app with a file list, live preview, and tag filter.",
  },
];

const STEPS = [
  { id: "brief" as AgentId, caption: "Interview, then a spec." },
  { id: "plan" as AgentId, caption: "Architecture and file map." },
  { id: "build" as AgentId, caption: "A small, complete project." },
  { id: "review" as AgentId, caption: "Critic reads every file." },
];

export function HomePage() {
  const navigate = useNavigate();
  const hydrated = useSessionStore((s) => s.hydrated);
  const order = useSessionStore((s) => s.order);
  const sessionsMap = useSessionStore((s) => s.sessions);
  const startSession = useSessionStore((s) => s.startSession);
  const sessions = order
    .map((id) => sessionsMap[id])
    .filter((s): s is NonNullable<typeof s> => Boolean(s));
  const [task, setTask] = useState("");
  const [opening, setOpening] = useState(false);
  const [ai, setAi] = useState<boolean | null>(null);

  useEffect(() => {
    void getAiStatus().then((r) => setAi(r.available));
  }, []);

  async function openSession(brief: string) {
    const trimmed = brief.trim();
    if (!trimmed || opening) return;
    setOpening(true);
    const session = startSession(trimmed);
    void navigate({ to: "/studio/$id", params: { id: session.id } });
    void askFirstQuestion(session.id);
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="mx-auto flex w-full max-w-5xl items-center justify-between px-5 py-5">
        <Wordmark />
        <p className="hidden text-xs text-faint sm:block">Sessions stay on this device</p>
      </header>

      <main className="mx-auto w-full max-w-5xl px-5 pb-20 pt-6 sm:pt-14">
        <p className="stagger-in text-xs font-medium uppercase tracking-[0.18em] text-faint">
          Multi-agent studio
        </p>
        <h1 className="stagger-in mt-4 max-w-2xl font-display text-4xl font-medium tracking-tight text-fg sm:text-6xl">
          Four specialists.
          <span className="block text-muted">One brief.</span>
        </h1>
        <p className="stagger-in mt-5 max-w-xl text-base text-muted">
          Quorum interviews you, drafts the plan, writes the files, and reviews the result — then
          hands the project back.
        </p>

        {ai === false ? (
          <p className="stagger-in mt-4 text-sm text-warn">
            AI is not available in this environment. You can still browse the studio, but sessions
            cannot run.
          </p>
        ) : null}

        <form
          className="stagger-in mt-10 rounded-xl bg-elevated p-3 shadow-[var(--shadow-border)] sm:p-4"
          onSubmit={(e) => {
            e.preventDefault();
            void openSession(task);
          }}
        >
          <label htmlFor="brief" className="px-1 text-xs font-medium uppercase tracking-[0.14em] text-faint">
            Brief
          </label>
          <Textarea
            id="brief"
            value={task}
            onChange={(e) => setTask(e.target.value)}
            onKeyDown={(e) => {
              if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
                e.preventDefault();
                void openSession(task);
              }
            }}
            placeholder="Describe the software you want built…"
            className="mt-2 min-h-32 resize-y bg-bg"
            disabled={opening || ai === false}
          />
          <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-wrap gap-2">
              {EXAMPLES.map((ex) => (
                <button
                  key={ex.label}
                  type="button"
                  className="h-11 rounded-full bg-subtle px-3 text-xs text-muted transition-colors duration-150 hover:text-fg"
                  onClick={() => setTask(ex.task)}
                >
                  {ex.label}
                </button>
              ))}
            </div>
            <Button type="submit" disabled={!task.trim() || opening || ai === false} className="w-full sm:w-auto">
              Open a session
              <ArrowRight />
            </Button>
          </div>
        </form>

        <section className="mt-16">
          <h2 className="text-xs font-medium uppercase tracking-[0.14em] text-faint">How a session runs</h2>
          <ol className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((step) => {
              const meta = AGENT_META[step.id];
              return (
                <li
                  key={step.id}
                  className="rounded-lg bg-elevated p-4 shadow-[var(--shadow-border)]"
                >
                  <p className="font-mono text-xs tabular-nums text-faint">{meta.index}</p>
                  <p className="mt-3 font-display text-xl font-medium text-fg">{meta.name}</p>
                  <p className="text-xs text-muted">{meta.title}</p>
                  <p className="mt-3 text-sm text-muted">{step.caption}</p>
                </li>
              );
            })}
          </ol>
        </section>

        <section className="mt-16">
          <h2 className="text-xs font-medium uppercase tracking-[0.14em] text-faint">Recent sessions</h2>
          {!hydrated ? (
            <p className="mt-4 text-sm text-faint">Loading sessions…</p>
          ) : sessions.length === 0 ? (
            <p className="mt-4 text-sm text-muted">No sessions yet. Open one with a brief above.</p>
          ) : (
            <ul className="mt-4 divide-y divide-border rounded-lg bg-elevated shadow-[var(--shadow-border)]">
              {sessions.slice(0, 8).map((s) => (
                <li key={s.id}>
                  <Link
                    to="/studio/$id"
                    params={{ id: s.id }}
                    className="flex items-center justify-between gap-4 px-4 py-3.5 transition-colors duration-150 hover:bg-subtle"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm text-fg">{truncate(s.task, 90)}</p>
                      <p className="mt-0.5 flex items-center gap-1.5 text-xs text-faint">
                        <Clock3 className="size-3" />
                        {formatRelative(s.updatedAt)}
                        <span className="text-border-strong">·</span>
                        <span className="capitalize">{s.phase}</span>
                      </p>
                    </div>
                    <ArrowRight className="size-4 shrink-0 text-faint" />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
    </div>
  );
}
